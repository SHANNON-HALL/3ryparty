.. _rfcs:

*****************************************************************************
 Request for Comments
*****************************************************************************

A PROJ RFC describes a major change in the technological underpinnings of
PROJ, major additions to functionality, or changes in the direction of
the project.

.. toctree::
   :maxdepth: 1

   rfc-1
   rfc-2
   rfc-3
   rfc-4
   rfc-5
