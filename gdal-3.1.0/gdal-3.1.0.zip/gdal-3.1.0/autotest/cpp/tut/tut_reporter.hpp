#ifndef TUT_REPORTER
#define TUT_REPORTER

#include <tut_console_reporter.hpp>

namespace tut
{
    typedef console_reporter reporter;
}

#endif
