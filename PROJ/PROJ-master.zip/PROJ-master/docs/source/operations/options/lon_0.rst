.. option:: +lon_0=<value>

    Longitude of projection center.

    *Defaults to 0.0.*
