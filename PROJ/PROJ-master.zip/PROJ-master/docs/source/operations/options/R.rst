.. option:: +R=<value>

    Radius of the sphere given in meters. If used in conjunction with ``+ellps``
    ``+R`` takes precedence.
