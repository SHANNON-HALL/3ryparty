.. option:: +t_epoch=<time>

    Central epoch of the transformation.
