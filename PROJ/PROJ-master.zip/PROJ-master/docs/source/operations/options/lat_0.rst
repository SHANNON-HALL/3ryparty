.. option:: +lat_0=<value>

    Latitude of projection center.

    *Defaults to 0.0.*
