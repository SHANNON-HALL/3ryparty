.. _crs:

crs namespace
-------------

.. doxygennamespace:: osgeo::proj::crs
   :project: doxygen_api
   :members:
