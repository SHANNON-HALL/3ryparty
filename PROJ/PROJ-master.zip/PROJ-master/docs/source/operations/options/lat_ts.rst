.. option:: +lat_ts=<value>

    Latitude of true scale. Defines the latitude where scale is not distorted.
    Takes precedence over ``+k_0`` if both options are used together.

    *Defaults to 0.0.*
