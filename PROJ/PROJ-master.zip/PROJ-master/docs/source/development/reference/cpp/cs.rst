.. _cs:

cs namespace
------------

.. doxygennamespace:: osgeo::proj::cs
   :project: doxygen_api
   :members:
