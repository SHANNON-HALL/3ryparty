.. option:: +lat_1=<value>

    First standard parallel.

    *Defaults to 0.0.*
