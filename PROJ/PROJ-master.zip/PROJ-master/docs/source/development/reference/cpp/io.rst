.. _io:

io namespace
------------

.. doxygennamespace:: osgeo::proj::io
   :project: doxygen_api
   :members:
