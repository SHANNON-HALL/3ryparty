.. _references:

.. only:: not latex

    ================================================================================
    References
    ================================================================================

.. bibliography:: references.bib
   :cited:
   :style: customstyle
