.. _cpp_general:

General documentation
---------------------

.. doxygenfile:: general_doc.dox.reworked.h
   :project: doxygen_api
