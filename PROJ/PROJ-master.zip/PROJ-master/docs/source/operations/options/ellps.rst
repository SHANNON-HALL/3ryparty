.. option:: +ellps=<value>

    See :option:`proj -le` for a list of available ellipsoids.

    *Defaults to "GRS80".*
